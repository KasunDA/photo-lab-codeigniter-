<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Upload_files extends CI_Controller

{

	function  __construct() {

		parent::__construct();

		$this->load->model('file');

	}

	

	function index(){

		$data = array();
		
		if($this->input->post('per_page'))
		{
			$per_page = $this->input->post('per_page');
		}
		else
		{
			$per_page = 8;
		}

		if($this->input->post('fileSubmit') && !empty($_FILES['userFiles']['name'])){

			$filesCount = count($_FILES['userFiles']['name']);

			for($i = 0; $i < $filesCount; $i++){

				$_FILES['userFile']['name'] = $_FILES['userFiles']['name'][$i];

				$_FILES['userFile']['type'] = $_FILES['userFiles']['type'][$i];

				$_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];

				$_FILES['userFile']['error'] = $_FILES['userFiles']['error'][$i];

				$_FILES['userFile']['size'] = $_FILES['userFiles']['size'][$i];



				$uploadPath = 'uploads/files/';

				$config['upload_path'] = $uploadPath;

				$config['allowed_types'] = 'gif|jpg|png';

				//$config['max_size']	= '100';

				//$config['max_width'] = '1024';

				//$config['max_height'] = '768';

				

				$this->load->library('upload', $config);

				$this->upload->initialize($config);

				if($this->upload->do_upload('userFile')){

					//$tags = array();
					$tags = $this->input->post("tag");
					
					if(!$tags){
						$tags = array('');
						array_push($tags, "'Other'");
					}

					$fileData = $this->upload->data();

					$uploadData[$i]['file_name'] = $fileData['file_name'];

					$uploadData[$i]['tags'] = implode(",",$tags);

					$uploadData[$i]['created'] = date("Y-m-d H:i:s");

					$uploadData[$i]['modified'] = date("Y-m-d H:i:s");

					$uploadData[$i]['coustmer_id'] = $this->input->post("coustmer_id");

				}

			}

			if(!empty($uploadData)){

				//Insert files data into the database

				$insert = $this->file->insert($uploadData);



				$statusMsg = $insert?'Files uploaded successfully.':'Some problem occurred, please try again.';



				$this->session->set_flashdata('feedback', $statusMsg);

				$this->session->set_flashdata('feedback_class', 'alert-success');

			}

		}

	

        //pagination	

			$this->load->library('pagination');

			$config = [

				'base_url' => base_url('upload_files/index'),

				'per_page' => $per_page,

				'total_rows' => $this->file->num_rows(),

				'full_tag_open' => '<ul class="pagination">',

				'full_tag_close' => '</ul>',

				'first_link' => '<li>First',

				'last_link' => '<li>Last',

				'next_tag_open' => '<li>',

				'next_tag_close' => '</li>',

				'prev_tag_open' => '<li>',

				'prev_tag_close' => '</li>',

				'num_tag_open' => '<li>',

				'num_tag_close' => '</li>',

				'cur_tag_open' => '<li class="active"><a>',

				'cur_tag_close' => '</a></li>', 

			];

			$this->pagination->initialize($config);

			//get files data from database

	        $files = $this->file->getRows('',$config['per_page'], $this->uri->segment(3));

	        $this->load->model('adminmodel');

	        $coustmers = $this->adminmodel->all_coustomer();

		//pass the files data to view

		$this->load->view('upload_files/index', compact('files','coustmers'));

	}



	public function delete_file($file_id)

	{

		if ($file_name = $this->file->delete_file($file_id)) {

			unlink("uploads/files/{$file_name}");

			$this->session->set_flashdata('feedback','File deleted successfully.');

			$this->session->set_flashdata('feedback_class', 'alert-success');

		}else{

			$this->session->set_flashdata('feedback','Fail to delete file..!');

			$this->session->set_flashdata('feedback_class', 'alert-danger');

		}



		return redirect('upload_files');

	}



}