<?php

class Login extends CI_Controller
{
	public function index()
	{
		$this->load->view("admin/login");
	}

	public function do_login()
	{
		$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');
		if($this->form_validation->run('admin_login'))
		{
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$this->load->model('loginmodel');

			if($user_id = $this->loginmodel->check_login($username,$password)){
				
 				$this->session->set_userdata("user_id", $user_id);

 				$this->session->set_flashdata("login_success", "Login Successful.Welcome Admin");
							
 				return redirect('admin/dashboard');
			}
			else
			{
				$this->session->set_flashdata("login_failed", "Username Or Password Incorrect..!");
				$this->session->set_flashdata("error_class", 'alert-danger');

				return redirect("login/index");

			}

		}else
		{
			$this->load->view("admin/login");
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('user_id');
		return $this->index();
	}
}