<?php



class Coustmer extends CI_Controller{



	function  __construct() {

		parent::__construct();

		$this->load->model('file');

	}

	

	public function index()

	{

		$this->load->view('coustmer/index');

	}



	public function login()

	{



		if($this->form_validation->run('admin_login'))

		{

			$username = $this->input->post('username');

			$password = $this->input->post('password');



			$this->load->model('loginmodel');



			if($coustmer_id = $this->loginmodel->check_coustmer_login($username,$password)){

				

 				$this->session->set_userdata("coustmer_id", $coustmer_id);



 				$this->session->set_flashdata("login_success", "Login Successful.Welcome Admin");

							

 				return redirect('coustmer/dashboard1');

			}

			else

			{

				$this->session->set_flashdata("login_failed", "Username Or Password Incorrect..!");

				$this->session->set_flashdata("error_class", 'alert-danger');



				return redirect("/");



			}



		}else

		{

			$this->load->view("coustmer/index");

		}

	}



	public function logout()

	{

		$this->session->unset_userdata('coustmer_id');

		return redirect('/');

	}



	public function dashboard()

	{

		if(! $this->session->userdata('coustmer_id'))

		{

			return redirect('/');

		}



		$this->load->library('pagination');

		$config = [

			'base_url' => base_url('coustmer/dashboard'),

			'per_page' => 8,

			'total_rows' => $this->file->num_rowsById(),

			'full_tag_open' => '<ul class="pagination">',

			'full_tag_close' => '</ul>',

			'first_link' => '<li>First',

			'last_link' => '<li>Last',

			'next_tag_open' => '<li>',

			'next_tag_close' => '</li>',

			'prev_tag_open' => '<li>',

			'prev_tag_close' => '</li>',

			'num_tag_open' => '<li>',

			'num_tag_close' => '</li>',

			'cur_tag_open' => '<li class="active"><a>',

			'cur_tag_close' => '</a></li>', 

		];

		$this->pagination->initialize($config);



		//get files data from database

        $files = $this->file->getRowsById($this->session->userdata('coustmer_id'),$config['per_page'], $this->uri->segment(3));



		//pass the files data to view

		$this->load->view("coustmer/dashboard", compact('files'));

	}



	public function download_file($file_name)

	{

		$this->load->helper('download');

		$data = file_get_contents("uploads/files/{$file_name}"); // Read the file's contents

		$name = $file_name;



		force_download($name, $data);

	}

	public function dashboard1()
	{
		if(! $this->session->userdata('coustmer_id'))

		{

			return redirect('/');

		}



		$this->load->library('pagination');

		$config = [

			'base_url' => base_url('coustmer/dashboard1'),

			'per_page' => 10,

			'total_rows' => $this->file->num_rowsById(),

			'full_tag_open' => '<ul class="pagination">',

			'full_tag_close' => '</ul>',

			'first_link' => '<li>First',

			'last_link' => '<li>Last',

			'next_tag_open' => '<li>',

			'next_tag_close' => '</li>',

			'prev_tag_open' => '<li>',

			'prev_tag_close' => '</li>',

			'num_tag_open' => '<li>',

			'num_tag_close' => '</li>',

			'cur_tag_open' => '<li class="active"><a>',

			'cur_tag_close' => '</a></li>', 

		];

		$this->pagination->initialize($config);



		//get files data from database

        $files = $this->file->getRowsById($this->session->userdata('coustmer_id'),$config['per_page'], $this->uri->segment(3));



		//pass the files data to view

		$this->load->view("coustmer/dashboard1", compact('files'));
	}

}