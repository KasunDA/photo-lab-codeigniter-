<?php



class Admin extends CI_Controller {



	public function __construct()

	{

		parent::__construct();

		if(! $this->session->userdata('user_id'))

		{

			return redirect('login/index');

		}

	}



	public function dashboard()

	{

		$this->load->view("admin/dashboard");

	}



	public function add_account()

	{

		$this->load->model('adminmodel');

		$this->load->library('pagination');

		$config = [

			'base_url' => base_url('admin/add_account'),

			'per_page' => 2,

			'total_rows' => $this->adminmodel->coustomer_row(),

			'full_tag_open' => '<ul class="pagination">',

			'full_tag_close' => '</ul>',

			'first_link' => '<li>First',

			'last_link' => '<li>Last',

			'next_tag_open' => '<li>',

			'next_tag_close' => '</li>',

			'prev_tag_open' => '<li>',

			'prev_tag_close' => '</li>',

			'num_tag_open' => '<li>',

			'num_tag_close' => '</li>',

			'cur_tag_open' => '<li class="active"><a>',

			'cur_tag_close' => '</a></li>', 

		];



		$this->pagination->initialize($config);



		$coustmers = $this->adminmodel->coustomer_list($config['per_page'], $this->uri->segment(3));



		$this->load->view('admin/add_account', ['coustmers' => $coustmers]);

	}



	public function test()

	{

		$this->load->view("admin/test");

	}



	public function store_account()

	{

		$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

		if($this->form_validation->run('add_coustomer_account'))

		{

			$post = $this->input->post(); 

			unset($post['submit']);

			$this->load->model('adminmodel');



			if($this->adminmodel->store_account($post)){

				$this->session->set_flashdata('feedback','Account created successfully.');

				$this->session->set_flashdata('feedback_class', 'alert-success');

			}else{

				$this->session->set_flashdata('feedback','Fail to create account..!');

				$this->session->set_flashdata('feedback_class', 'alert-danger');

			}



			return redirect('admin/add_account');



		}

		else

		{

			 $this->add_account();

		}



	}

	public function delete_account()

	{

		$coustmer_id = $this->input->post('coustmer_id');



		$this->load->model('adminmodel');

		if ($this->adminmodel->delete_coustmer($coustmer_id)) {

			$this->session->set_flashdata('feedback','Account deleted successfully.');

			$this->session->set_flashdata('feedback_class', 'alert-success');

		}else{

			$this->session->set_flashdata('feedback','Fail to delete account..!');

			$this->session->set_flashdata('feedback_class', 'alert-danger');

		}



		return redirect('admin/add_account');

	}



	public function find_account($coustmer_id)

	{

			$this->load->model('adminmodel');

			

			if($acc= $this->adminmodel->find_account($coustmer_id)){



				$this->load->library('pagination');

			$config = [

				'base_url' => base_url("admin/find_account/{$coustmer_id}"),

				'per_page' => 2,

				'total_rows' => $this->adminmodel->coustomer_row(),

				'full_tag_open' => '<ul class="pagination">',

				'full_tag_close' => '</ul>',

				'first_link' => '<li>First',

				'last_link' => '<li>Last',

				'next_tag_open' => '<li>',

				'next_tag_close' => '</li>',

				'prev_tag_open' => '<li>',

				'prev_tag_close' => '</li>',

				'num_tag_open' => '<li>',

				'num_tag_close' => '</li>',

				'cur_tag_open' => '<li class="active"><a>',

				'cur_tag_close' => '</a></li>', 

			];



			$this->pagination->initialize($config);



			$coustmers = $this->adminmodel->coustomer_list($config['per_page'], $this->uri->segment(3));

			

			$this->load->view('admin/add_account', ['acc' => $acc,'coustmers' => $coustmers]);

		

		}else{



			$this->session->set_flashdata('feedback', 'No record found..!');

			$this->session->set_flashdata('feedback_class', 'alert-danger');	

		}



	}



	public function update_account($account_id)

	{

		$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

		if($this->form_validation->run('add_coustomer_account'))

		{

			$post = $this->input->post(); 

			unset($post['submit']);

			$this->load->model('adminmodel');



			if($this->adminmodel->update_account($account_id,$post)){

				$this->session->set_flashdata('feedback','Account updated successfully.');

				$this->session->set_flashdata('feedback_class', 'alert-success');

			}else{

				$this->session->set_flashdata('feedback','Fail to update account..!');

				$this->session->set_flashdata('feedback_class', 'alert-danger');

			}



			return redirect('admin/add_account');

		}

		else

		{

			 $this->add_account();

		}



	}

	public function search($coustmer,$date)
	{	
		$this->load->model('adminmodel');
		$coustmers = $this->adminmodel->all_coustomer();
		
		$files = $this->adminmodel->search($coustmer,$date);

		$this->load->view('admin/search_file', compact('files','coustmers'));		
	}


}