<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  <?php $burl= base_url(); ?>
body { background-image: url("<?= $burl ?>/uploads/back5.jpg");
background-size: 100%; }


</style>
	<title>Admin login</title>
	<?= link_tag('assets/css/bootstrap.css'); ?>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?= base_url(); ?>">Photo-lab</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
      <ul class="nav navbar-nav">
        <li class="<?php if(uri_string() == "admin/add_account"){ echo "active"; } ?> "><a href="#">Home<span class="sr-only">(current)</span></a></li>
        <li class="<?php if(uri_string() == "upload_files"){ echo "active"; } ?> "><a href="#">About-us</a></li>
        <!-- <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Dropdown <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li class="divider"></li>
            <li><a href="#">One more separated link</a></li>
          </ul>
        </li> -->
      </ul>
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Contact-us</a></li>
      </ul>
    </div>
  </div>
</nav>


<div class="col-lg-4 col-lg-offset-8 " style="margin-top: 8em;">
<?php if($error = $this->session->flashdata('login_failed')):
  $error_class = $this->session->flashdata('error_class');
   ?>
  <div class="row">
    <div class="col-lg-11 alert alert-dismissible <?= $error_class; ?>">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?= $error; ?>
    </div>
  </div>
 <?php endif; ?>

  <?= form_open("coustmer/login", ['class' => 'form-horizontal']) ?>
    <fieldset>
      <div class="form-group <?php if(form_error('password')){ echo 'has-error';} ?>">
        <label for="inputEmail" class="col-lg-3 control-label">Email</label>
        <div class="col-lg-8">
          <?= form_input(['name' => 'username', 'class' => 'form-control', 'id' => 'username', 'placeholder' => 'User Name','value' => set_value('username')]); ?>
        </div>
      </div>
      <div class="form-group <?php if(form_error('password')){ echo'has-error'; } ?>">
        <label for="inputPassword" class="col-lg-3 control-label">Password</label>
        <div class="col-lg-8">
            <?= form_password(['name' => 'password', 'class' => 'form-control', 'id' => 'password', 'placeholder' => 'Password']); ?>
        </div>
      </div>

      <div class="form-group">
        <div class="col-lg-10 col-lg-offset-3">
          
          <button type="submit" class="btn btn-primary">Login</button>
        </div>
      </div>
    </fieldset>

    <?= form_close() ?>

</div>

</body>
<script   src="https://code.jquery.com/jquery-2.2.4.min.js"   integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="   crossorigin="anonymous"></script>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
</html>