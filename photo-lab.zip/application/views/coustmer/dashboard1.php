<?php require_once("coustmer_header.php"); ?>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
	<link rel="shortcut icon" href="../favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/demo.css'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/elastic_grid.min.css'); ?>" />
</head>
<body style="background:#fff;">
<div id="elastic_grid_demo"></div>
<div class="col-lg-12">
<?= $this->pagination->create_links(); ?>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="<?= base_url('assets/js/modernizr.custom.js'); ?>"></script>
<script src="<?= base_url('assets/js/classie.js'); ?>"></script>
<!--- uncompress-->
<!-- <script type="text/javascript" src="js/jquery.elastislide.js"></script>
<script type="text/javascript" src="js/jquery.hoverdir.js"></script>
<script type="text/javascript" src="js/elastic_grid.js"></script> -->

<!-- compress version-->
<script type="text/javascript" src="<?= base_url('assets/js/elastic_grid.min.js') ?>"></script>

<script type="text/javascript">
    $(function(){
        $("#elastic_grid_demo").elastic_grid({
            'showAllText' : 'All',
            'filterEffect': 'popup', // moveup, scaleup, fallperspective, fly, flip, helix , popup
            'hoverDirection': true,
            'hoverDelay': 0,
            'hoverInverse': false,
            'expandingSpeed': 500,
            'expandingHeight': 500,
            'items' :
            [
            <?php if(!empty($files)): foreach($files as $file): ?>
                {
                    'title'         : '<?= $file['file_name'] ?>',
                    'thumbnail'     :
                     [
                     '<?= base_url("uploads/files/".$file['file_name']); ?>'
                     ],
                    'large'         : 
                    [
                    '<?= base_url("uploads/files/".$file['file_name']); ?>'
                    ],
                    'button_list'   :
                    [
                        { 'title':'Download', 'url':'<?= base_url("coustmer/download_file/"); ?>/<?= $file["file_name"]?>', 'new_window' : false}
                    ],
                    'tags'          : [<?= $file["tags"];?>]
                },
                <?php endforeach;endif; ?>
            ]
        });
    });
</script>

</body>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>