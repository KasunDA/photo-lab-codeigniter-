<?php require_once("coustmer_header.php"); ?>
<style>
ul.gallery {
    clear: both;
    float: left;
    width: 100%;
    margin-bottom: -10px;
    padding-left: 3px;
}
ul.gallery li.item {
    width: 23%;
    height: 215px;
    display: block;
    float: left;
    margin: 0px 15px 15px 0px;
    font-size: 12px;
    font-weight: normal;
    background-color: d3d3d3;
    padding: 10px;
    box-shadow: 10px 10px 5px #888888;
}

.item img{width: 100%; height: 184px;}

.item p {
    color: #6c6c6c;
    letter-spacing: 1px;
    text-align: center;
    position: relative;
    margin: 5px 0px 0px 0px;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-lg-12"> 

        <?php if($error = $this->session->flashdata('feedback')):
          $error_class = $this->session->flashdata('feedback_class');
           ?>
            <div class="col-lg-6 alert alert-dismissible <?= $error_class; ?>">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <?= $error; ?>
            </div>
          <?php endif; ?>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <ul class="gallery">
                    <?php if(!empty($files)): foreach($files as $file): ?>
                        <?php $i=$this->uri->segment(3, 0); ?>
                    <li class="item">
                        <img src="<?php echo base_url('uploads/files/'.$file['file_name']); ?>" alt="" >
                        <p>Uploaded On <?php echo date("j M Y",strtotime($file['created'])); ?>
                        <span class="pull-right"><a href='<?= base_url("coustmer/download_file/"); ?>/<?= $file["file_name"]?>'><img src="<?= base_url("uploads/down1.png") ?>" style="width: 28px;height: 20px;"></a></span>
                        </p>
                    </li>
                    <?php endforeach; else: ?>
                    <p>File(s) not found.....</p>
                    <?php endif; ?>
                </ul>
                 <?= $this->pagination->create_links(); ?>
            </div>
        </div>
    </div>
</div>

<?php require_once("coustmer_footer.php"); ?>