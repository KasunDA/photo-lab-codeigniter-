<?php require_once("admin_header.php"); ?>
<div class="container">
  <?php if($error = $this->session->flashdata('feedback')):
  $error_class = $this->session->flashdata('feedback_class');
   ?>
  <div class="row">
    <div class="col-lg-6 alert alert-dismissible <?= $error_class; ?>">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?= $error; ?>
    </div>
  </div>
  <?php endif; ?>
  <div class="col-lg-8">
   <?php if(isset($acc)): ?>
    <?= form_open("admin/update_account/{$acc->id}",['class' => 'form-horizontal']) ?>
  <?php else: ?>
    <?= form_open("admin/store_account",['class' => 'form-horizontal']) ?>
  <?php endif;?>
      <fieldset>
        <legend><?= isset($acc)?"Update":"Add"; ?> Coustomer Account</legend>
        <div class="row">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="inputEmail" class="col-lg-4 control-label">First Name</label>
              <div class="col-lg-8">
                <?= form_input(['name' => 'fname', 'class' => 'form-control', 'id' => 'fname', 'placeholder' => 'First Name','value' => isset($acc)? $acc->fname:set_value('fname')]); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?= form_error('fname'); ?>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="inputEmail" class="col-lg-4 control-label">Last Name</label>
              <div class="col-lg-8">
                <?= form_input(['name' => 'lname', 'class' => 'form-control', 'id' => 'lname', 'placeholder' => 'Last Name','value' =>  isset($acc)? $acc->lname:set_value('lname')]); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?= form_error('lname'); ?>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="inputEmail" class="col-lg-4 control-label">User Name</label>
              <div class="col-lg-8">
                <?= form_input(['name' => 'username', 'class' => 'form-control', 'id' => 'username', 'placeholder' => 'User Name','value' =>  isset($acc)? $acc->username:set_value('username')]); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?= form_error('username'); ?>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="inputPassword" class="col-lg-4 control-label">Password</label>
              <div class="col-lg-8">
                <?= form_password(['name' => 'password', 'class' => 'form-control', 'id' => 'password', 'placeholder' => 'Password','value' =>  isset($acc)? $acc->password:'']); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?= form_error('password'); ?>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="inputEmail" class="col-lg-4 control-label">Email</label>
              <div class="col-lg-8">
                <?= form_input(['name' => 'email', 'class' => 'form-control', 'id' => 'email', 'placeholder' => 'Email','value' =>  isset($acc)? $acc->email:set_value('email')]); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?= form_error('email'); ?>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="inputEmail" class="col-lg-4 control-label">Contact No.</label>
              <div class="col-lg-8">
                <?= form_input(['name' => 'contact_no', 'class' => 'form-control', 'id' => 'contact_no', 'placeholder' => 'Contact No.','value' =>  isset($acc)? $acc->contact_no:set_value('contact_no')]); ?>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?= form_error('contact_no'); ?>
          </div>
        </div>
        
        <div class="form-group">
          <div class="col-lg-10 col-lg-offset-2">
            <?= form_submit(['value' =>  isset($acc)? 'Update':'Submit', 'class' => 'btn btn-primary']); ?>
            <a href="<?= base_url("admin/add_account"); ?>" class="btn btn-default">Cancel</a>

          </div>
        </div>
      </fieldset>
    <?= form_close(); ?>
  </div>


  <div class="col-lg-4">
  <hr><hr>
    <table class="table">
      <thead>
        <tr>
          <th>Sno.</th>
          <th>Name</th>
          <th>ID</th>
          <th>Password</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(count($coustmers)): 
        $i=$this->uri->segment(3, 0); ?>
        
          <?php foreach($coustmers as $coustmer): ?>
            <tr>
              <td><?= ++$i; ?></td>
              <td><a href="<?= base_url("admin/find_account/{$coustmer->id}"); ?>"> <?= $coustmer->fname ?> <?= $coustmer->lname ?></a></td>
              <td><?= $coustmer->username ?></td>
              <td><?= $coustmer->password ?></td>
              <td>
                <?= form_open('admin/delete_account'),
                form_hidden('coustmer_id', $coustmer->id),
                form_submit(['name' => 'Submit','value'=>'Delete','class'=> 'btn btn-danger','onclick'=> 'return confirm("Are you sure ?")']),
                form_close();
                  ?>
              </td>
            </tr>
        <?php endforeach; ?>
      <?php else:?>
        <tr>
          <td colspan="4">No Records Found. </td>
        </tr>
      <?php endif; ?>  
      </tbody>
    </table>
    <?= $this->pagination->create_links(); ?>
  </div>
</div>

<?php require_once("admin_footer.php"); ?>