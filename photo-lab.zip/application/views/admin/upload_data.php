<?php require_once("admin_header.php"); ?>
<div class="container">
  <?php if($error = $this->session->flashdata('feedback')):
  $error_class = $this->session->flashdata('feedback_class');
   ?>
  <div class="row">
    <div class="col-lg-6 alert alert-dismissible <?= $error_class; ?>">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <?= $error; ?>
    </div>
  </div>
  <?php endif; ?>
 <div class="col-lg-6">
 <?= form_open_multipart('admin/do_upload', ['class'=>'form-horizontal']); ?>
 	<form class="">
	  <fieldset>
	    <legend>Upload Form</legend>
	    <div class="form-group">
	      <label for="inputEmail" class="col-lg-2 control-label">Title</label>
	      <div class="col-lg-10">
	        <input type="text" name="title" class="form-control" id="inputTitle" placeholder="Title">
	      </div>
	    </div>

	    <div class="form-group">
	      <label for="textArea" class="col-lg-2 control-label">Description</label>
	      <div class="col-lg-10">
	        <textarea name="description" class="form-control" rows="3" id="description"></textarea>
	        <span class="help-block">A longer block of help text that breaks onto a new line and may extend beyond one line.</span>
	      </div>
	    </div>
	    <div class="form-group">
	      <label class="col-lg-2 control-label">Pictures</label>
	      <div class="col-lg-10">
	        <input type="file" name="pic[]" class="form-control" multiple="" id="pic">
	      </div>
	    </div>

	    <div class="form-group">
	      <div class="col-lg-10 col-lg-offset-2">
	        <button type="submit" class="btn btn-primary">Submit</button>
	        <button type="reset" class="btn btn-default">Cancel</button>
	      </div>
	    </div>
	  </fieldset>
	  	<?= form_close(); ?>
 </div>

</div>
<?php require_once("admin_footer.php"); ?>