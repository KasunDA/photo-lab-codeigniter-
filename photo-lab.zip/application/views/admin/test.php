<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>" type="text/css"/>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
 
<!-- Include the plugin's CSS and JS: -->
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap-multiselect.min.js'); ?>"></script>
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap-multiselect.css'); ?>" type="text/css"/>

<select id="example-getting-started" multiple="multiple">
    <option value="cheese">Cheese</option>
    <option value="tomatoes">Tomatoes</option>
    <option value="mozarella">Mozzarella</option>
    <option value="mushrooms">Mushrooms</option>
    <option value="pepperoni">Pepperoni</option>
    <option value="onions">Onions</option>
</select>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example-getting-started').multiselect();
    });
</script>