<?php require_once("admin_header.php"); ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<style>
ul.gallery {
    clear: both;
    float: left;
    width: 100%;
    margin-bottom: -10px;
    padding-left: 3px;
}
ul.gallery li.item {
    width: 23%;
    height: 215px;
    display: block;
    float: left;
    margin: 0px 15px 15px 0px;
    font-size: 12px;
    font-weight: normal;
    background-color: d3d3d3;
    padding: 10px;
    box-shadow: 10px 10px 5px #888888;
}

.item img{width: 100%; height: 184px;}

.item p {
    color: #6c6c6c;
    letter-spacing: 1px;
    text-align: center;
    position: relative;
    margin: 5px 0px 0px 0px;
}
</style>
<script type="text/javascript">
         
            function search_id() {
               var coustmer = document.getElementById('search_id').value;
               var date = null;

               window.location= "<?= base_url("admin/search/"); ?>/"+coustmer+ "/"+date ;
            }

            function search_date() {
               var coustmer = null;
               var date = document.getElementById('search_date').value;

               window.location= "<?= base_url("admin/search/"); ?>/"+coustmer+ "/"+date ;
            }

            function per_page_num(){
                //alert("hii");              
                 document.getElementById("myForm").submit();
            }
         
</script>
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>" type="text/css"/>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
 
<!-- Include the plugin's CSS and JS: -->
<script type="text/javascript" src="<?= base_url('assets/js/bootstrap-multiselect.min.js'); ?>"></script>
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap-multiselect.css'); ?>" type="text/css"/>
<div class="container">
    <div class="row">
        <div class="col-lg-12"> 
            <form enctype="multipart/form-data" action="" method="post">
            <div class="col-lg-6">
                <div class="form-group">
                    <label>Select Coustmer</label>
                    <select name="coustmer_id" class="form-control">
                        <option value="">Select Coustmer</option>
                        <?php foreach($coustmers as $coustmer):?>
                            <option value="<?= $coustmer->id ?>"><?= $coustmer->fname ." ".$coustmer->lname ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Choose Files</label>
                            <input type="file" class="form-control" name="userFiles[]" multiple/>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                        <label>Tags</label><br>
                        <select id="tag" class="form-control" name="tag[]" multiple="multiple">
                            <option value="'Other'" selected="selected">Other</option>
                            <option value="'cheese'">Cheese</option>
                            <option value="'tomatoes'">Tomatoes</option>
                            <option value="'Mozzarella'">Mozzarella</option>
                            <option value="'Mushrooms'">Mushrooms</option>
                            <option value="'Pepperoni'">Pepperoni</option>
                            <option value="'Onions'">Onions</option>
                        </select>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <input class="form-control" type="submit" name="fileSubmit" value="UPLOAD"/>
                </div>
            </div>
            </form>
                <?php if($error = $this->session->flashdata('feedback')):
                  $error_class = $this->session->flashdata('feedback_class');
                   ?>
                    <div class="col-lg-6 alert alert-dismissible <?= $error_class; ?>">
                      <button type="button" class="close" data-dismiss="alert">&times;</button>
                      <?= $error; ?>
                    </div>
                  <?php endif; ?>
                <div class="col-lg-6">
                <div class="col-lg-6">
                <div class="form-group">
                    <label>Sort by Coustmer</label>
                    <select name="search_id" id="search_id" class="form-control" onchange="search_id();">
                        <option value="">Select Coustmer</option>
                        <?php foreach($coustmers as $coustmer):?>
                            <option value="<?= $coustmer->id ?>"><?= $coustmer->fname ." ".$coustmer->lname ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                </div>

                <div class="col-lg-6">
                <div class="form-group">
                    <label>Sort by Date</label>
                    <input id="search_date" class="form-control" type="date" name="search_date" onchange="search_date();"/>
                </div>
                </div>
                <div class="col-lg-12">
                <form id="myForm" method="post" action="<?= base_url("upload_files/index"); ?>">
                    <div class="form-group">
                        <label>Record Per Page</label>
                        <select name="per_page" id="per_page" class="form-control" onchange="per_page_num();">
                            <option value="">Select..</option>
                            <option value="8">8</option>
                            <option value="10">10</option>
                            <option value="20">20</option>
                        </select>
                    </div>
                   </form> 
                </div>
                </div>
                 
        </div>
        <div class="col-lg-12">
            <div class="row">
                <ul class="gallery">
                    <?php if(!empty($files)): foreach($files as $file): ?>
                        <?php $i=$this->uri->segment(3, 0); ?>
                    <li class="item">
                        <img src="<?php echo base_url('uploads/files/'.$file['file_name']); ?>" alt="" >
                        <p>Uploaded On <?php echo date("j M Y",strtotime($file['created'])); ?>
                        <span class="pull-right"><a href='<?= base_url("upload_files/delete_file/"); ?>/<?= $file["id"]?>'>[X]</a></span>
                        </p>
                    </li>
                    <?php endforeach; else: ?>
                    <p>File(s) not found.....</p>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('#tag').multiselect();
    });
</script>
