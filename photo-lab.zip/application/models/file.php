<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class File extends CI_Model{

	public function getRows($id = '',$limit,$offset){
		$this->db->select('id,file_name,created,tags');
		$this->db->from('files');
		if($id){
			$this->db->where('id',$id);
			$query = $this->db->get();
			$result = $query->row_array();
		}else{
			$this->db->order_by('created','desc');
			$query = $this->db->limit($limit, $offset)->get();
			$result = $query->result_array();
		}
		return !empty($result)?$result:false;
	}

	public function getRowsById($id,$limit,$offset){
		$this->db->select('id,file_name,created,tags');
		$this->db->from('files');
		$this->db->where('coustmer_id',$id);
		$this->db->order_by('created','desc');
		$query = $this->db->limit($limit, $offset)->get();
		$result = $query->result_array();
		
		return !empty($result)?$result:false;
	}
	
	public function insert($data = array()){
		$insert = $this->db->insert_batch('files',$data);
		return $insert?true:false;
	}

	public function num_rows()
	{
		$this->db->select('id,file_name,created,tags');
		$this->db->from('files');
		$this->db->order_by('created','desc');
		$query = $this->db->get();

		return $query->num_rows;
	}

	public function num_rowsById()
	{
		$this->db->select('id,file_name,created,tags');
		$this->db->from('files');
		$this->db->where('coustmer_id',$this->session->userdata('coustmer_id'));
		$this->db->order_by('created','desc');
		$query = $this->db->get();

		return $query->num_rows;
	}

	public function delete_file($file_id)
	{
		$q = $this->db
				->select(['id','file_name'])
				->from('files')
				->where("id", $file_id)
				->get();

		$this->db->delete('files', ['id' => $file_id]);
		return isset($q)?$q->row()->file_name:FALSE;		
	}
	
}
