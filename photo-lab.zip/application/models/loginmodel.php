<?php

class Loginmodel extends CI_Model
{
	public function check_login($username,$password)
	{
		$q =  $this->db
				->where(["username" => $username,"password" => $password,"isAdmin" => "0"])
				->get("tbl_users");

		if($q->num_rows()){

			return $q->row()->id;
		
		}else{
		
			return FALSE;	
		}		
	}

	public function check_coustmer_login($username,$password)
	{
		$q =  $this->db
				->where(["username" => $username,"password" => $password,"isAdmin" => "1"])
				->get("tbl_users");

		if($q->num_rows()){

			return $q->row()->id;
		
		}else{
		
			return FALSE;	
		}		
	}
}