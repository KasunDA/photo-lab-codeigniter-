<?php



class Adminmodel extends CI_model

{

	public function store_account($array)

	{

		$affected_rows = $this->db->insert('tbl_users',$array);



 		if($affected_rows)

 		{

 			return TRUE;

 		}else

 		{

 			return FALSE;

 		}

	}



	public function update_account($account_id,Array $array)

	{

		return $this->db->where('id',$account_id)

									->update('tbl_users',$array);

	}



	public function coustomer_list($limit, $offset)

	{

		$q = $this->db

				->select(['id','fname','lname','username','password','contact_no'])

				->from('tbl_users')

				->limit($limit, $offset)

				->where('isAdmin','1')

				->get();



		return $q->result();

	}



	public function all_coustomer()

	{

		$q = $this->db

				->select(['id','fname','lname'])

				->from('tbl_users')

				->where('isAdmin','1')

				->get();



		return $q->result();

	}



	public function coustomer_row()

	{

		$q = $this->db

				->select(['id','fname','lname','username','password','contact_no'])

				->from('tbl_users')

				->where('isAdmin','1')

				->get();



		return $q->num_rows();

	}



	public function delete_coustmer($coustmer_id)

	{

		return $this->db->delete('tbl_users', ['id' => $coustmer_id]);

	}



	public function find_account($coustmer_id)

	{

		$q = $this->db

				->select(['id','fname','lname','username','password','contact_no','email'])

				->from('tbl_users')

				->where('id', $coustmer_id)

				->get();



		if($q){

			

			return $q->row();

		

		}else{



			return FALSE;

		}



	}

	public function search($coustmer,$date)
	{
		if($coustmer != 'null'){

			$q = $this->db
				->where('coustmer_id', $coustmer)
				->from('files')
				->get();
				
			return $q->result_array();

		}elseif($date != 'null'){
			
			$q = $this->db
				->like('created', $date)
				->from('files')
				->get();
				
			return $q->result_array();
		}
		
	}

}