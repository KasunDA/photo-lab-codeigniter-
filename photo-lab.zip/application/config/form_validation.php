<?php

$config = array(
                 'admin_login' => array(
                                    array(
                                            'field' => 'username',
                                            'label' => 'Username',
                                            'rules' => 'required'
                                         ),
                                    array(
                                            'field' => 'password',
                                            'label' => 'Password',
                                            'rules' => 'required'
                                         )
                                    ),
                 'add_coustomer_account' => array(
                                    array(
                                            'field' => 'fname',
                                            'label' => 'First Name',
                                            'rules' => 'required|alpha'
                                         ),
                                    array(
                                            'field' => 'lname',
                                            'label' => 'Last Name',
                                            'rules' => 'required|alpha'
                                         ),
                                    array(
                                            'field' => 'username',
                                            'label' => 'User Name',
                                            'rules' => 'required'
                                         ),
                                    array(
                                            'field' => 'password',
                                            'label' => 'Password',
                                            'rules' => 'required'
                                         ),
                                    array(
                                            'field' => 'contact_no',
                                            'label' => 'Contact Number',
                                            'rules' => 'required|numeric' 
                                        )
                                    )                          
               );